using Microsoft.AspNetCore.RateLimiting;
using System.Threading.RateLimiting;
using System.Text.Json;
using System.Text.RegularExpressions;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddSingleton<InquiryStore>();
builder.Services.AddRateLimiter(options => {
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    options.AddPolicy("inquiry", context => RateLimitPartition.GetFixedWindowLimiter(
        partitionKey: context.Connection.RemoteIpAddress?.ToString() ?? "unknown",
        factory: _ => new FixedWindowRateLimiterOptions {
            PermitLimit = 5, Window = TimeSpan.FromMinutes(10), QueueLimit = 0,
            AutoReplenishment = true
        }));
    options.OnRejected = async (context, token) => {
        await context.HttpContext.Response.WriteAsJsonAsync(new {
            message = "You have sent several enquiries. Please try again in a few minutes."
        }, token);
    };
});
var app = builder.Build();
app.Use(async (context, next) => {
    context.Response.Headers["X-Content-Type-Options"] = "nosniff";
    context.Response.Headers["X-Frame-Options"] = "SAMEORIGIN";
    context.Response.Headers["Referrer-Policy"] = "strict-origin-when-cross-origin";
    await next();
});
app.UseDefaultFiles();
app.UseStaticFiles();
app.UseRateLimiter();
app.MapGet("/api/health", () => Results.Ok(new { status = "ok" }));
app.MapGet("/api/business", (IConfiguration config) => Results.Ok(new {
    phone = config["Business:Phone"] ?? "", email = config["Business:Email"] ?? "",
    instagram = config["Business:Instagram"] ?? "", facebook = config["Business:Facebook"] ?? "",
    youtube = config["Business:Youtube"] ?? "", whatsapp = config["Business:Whatsapp"] ?? ""
}));
app.MapPost("/api/inquiries", async (InquiryInput input, InquiryStore store) => {
    string name = input.Name?.Trim() ?? "";
    string phone = input.Phone?.Trim() ?? "";
    string route = input.Route?.Trim() ?? "";
    string type = input.TripType?.Trim() ?? "";
    string notes = input.Notes?.Trim() ?? "";
    string packageId = input.PackageId?.Trim() ?? "";
    var indiaToday = DateOnly.FromDateTime(DateTimeOffset.UtcNow.ToOffset(TimeSpan.FromHours(5.5)).DateTime);
    if (name.Length is < 2 or > 80 || !Regex.IsMatch(phone, @"^[6-9]\d{9}$") || route.Length is < 3 or > 160 ||
        !new[] { "tour", "rental", "group" }.Contains(type) || notes.Length > 1000 ||
        (packageId.Length > 0 && !new[] { "kodai", "ooty", "rameswaram", "thanjavur", "yercaud", "custom" }.Contains(packageId)) ||
        input.TravelDate is null || input.TravelDate.Value < indiaToday || input.TravelDate.Value > indiaToday.AddYears(2) ||
        input.Passengers is < 1 or > 60 || !input.Consent)
        return Results.BadRequest(new { message = "Please check your name, mobile number, date, group size and contact consent." });
    var inquiry = new Inquiry(Guid.NewGuid().ToString("N").ToUpperInvariant(), name, phone, route, type,
        packageId, input.TravelDate.Value, input.Passengers, notes, DateTimeOffset.UtcNow);
    await store.Save(inquiry);
    return Results.Ok(new { reference = "TM-" + inquiry.Reference[..12], message = "Enquiry received. Availability will be confirmed with your quotation." });
}).RequireRateLimiting("inquiry");
app.Run();

record InquiryInput(string? Name, string? Phone, string? Route, string? TripType, string? PackageId,
    DateOnly? TravelDate, int Passengers, string? Notes, bool Consent);
record Inquiry(string Reference, string Name, string Phone, string Route, string TripType, string PackageId,
    DateOnly TravelDate, int Passengers, string Notes, DateTimeOffset CreatedAt);
sealed class InquiryStore(IWebHostEnvironment env) {
    readonly SemaphoreSlim gate = new(1, 1);
    readonly string path = Path.Combine(env.ContentRootPath, "Data", "inquiries.jsonl");
    public async Task Save(Inquiry inquiry) {
        await gate.WaitAsync();
        try {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            await File.AppendAllTextAsync(path, JsonSerializer.Serialize(inquiry) + Environment.NewLine);
        } finally { gate.Release(); }
    }
}
