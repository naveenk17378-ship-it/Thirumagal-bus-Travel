# Thirumagal Bus Travels — புதிய ASP.NET Core website

பெயர், design, colours, fonts, navigation, pages, footer அனைத்தும் புதிதாக அமைக்கப்பட்டுள்ளன.

## முதலில் website திறப்பது எப்படி?

உங்கள் கணினியில் .NET 10 ஏற்கனவே install செய்துவிட்டீர்கள். மீண்டும் install செய்ய வேண்டாம்.

1. பழைய website ஓடும் PowerShell-ல் **Ctrl + C** அழுத்துங்கள்.
2. இந்த ZIP-ஐ `G:\downloads` இடத்தில் Extract செய்யுங்கள். புதிய folder பெயர் `ThirumagalBusTravels`.
3. அந்த folder-க்குள் இருக்கும் **Start-Website.cmd** file-ஐ double-click செய்யுங்கள்.
4. `Now listening on: http://localhost:5000` வந்ததும் browser-ல் **http://localhost:5000** திறக்கவும்.
5. Browser பழைய design காட்டினால் **Ctrl + F5** அழுத்துங்கள்.
6. Website பயன்படுத்தும்போது terminal-ஐ திறந்தே வைத்திருக்கவும். நிறுத்த **Ctrl + C**.

Terminal மூலம் இயக்க விரும்பினால்:

```powershell
cd G:\downloads\ThirumagalBusTravels
dotnet run
```

Extract செய்ததில் மற்றொரு folder இருந்தால், **ThirumagalBusTravels.csproj உள்ள folder**-ல் command ஓட்டுங்கள்.

## இதில் என்ன இருக்கிறது?

- **Home**: bus hero, animated headings, quick trip planner, tour packages, services, coach overview, 3-step planning process, FAQ.
- **Packages**: Hills / Pilgrimage / Day trips / Custom filters; 6 suggested itineraries; itinerary details popup; inclusions / exclusions; direct enquiry link.
- **Our bus**: photo preview, fullscreen gallery, coach checklist.
- **About**: brand introduction, travel planning approach.
- **Contact**: name / phone / route / date / group size / package / notes / consent; actual server submission and reference number.
- **Footer**: social media SVG icons, package links, privacy / booking information, NUVORIX credit.
- Mobile drawer navigation, sticky header, smooth buttons, scroll reveals, subtle hero photo movement, FAQ accordions, mobile bottom enquiry button, back-to-top button.
- Reduced-motion device preference is respected. Date / phone / required field validation exists in both browser and ASP.NET.

## Package விவரங்கள்

இவை sample suggested itineraries; உங்கள் business-ல் உள்ள actual package என உறுதி செய்யப்படவில்லை. Website-ல் இதைத் தெளிவாகக் குறிப்பிட்டுள்ளோம்.

| Package | Suggested duration |
|---|---|
| Kodaikanal Escape | 2 days / 1 night |
| Ooty & Coonoor | 3 days / 2 nights |
| Rameswaram Journey | 2 days / 1 night |
| Thanjavur Day Out | 1 day |
| Yercaud Weekend | 2 days / 1 night |
| Your Own Route | Customer chooses |

விலை தரப்படாததால் **Quote on request** காட்டுகிறது. உண்மையான fare / inclusions / cancellation terms உறுதி செய்யப்பட்ட பிறகே சேர்க்கவும். Image-கள் illustrative stock photographs; destination-ன் உண்மையான படங்கள் என்று குறிப்பிடவில்லை.

## உங்கள் உண்மையான bus photo சேர்ப்பது

இந்த ZIP-ல் real stock photographs project-க்குள்ளேயே உள்ளன. உங்கள் அசல் பச்சை bus photo கிடைக்காததால் stock coach காட்டப்படுகிறது.

1. உங்கள் அசல் bus exterior photo-ஐ `wwwroot\images\bus-exterior.jpg` என்று வைக்கவும்.
2. Browser-ல் Ctrl + F5 அழுத்துங்கள். Hero / coach image தானாக உங்கள் படத்திற்கு மாறும்.
3. Bus colour, name, body shape, mirrors ஆகியவற்றை மாற்ற வேண்டாம்.
4. Interior front / rear, side view, seats, amenities, night interior photos கிடைத்ததும் actual gallery-ஐ விரிவாக்கலாம். இப்போது இல்லாத photos அல்லது வசதிகளை உருவாக்கி காட்டவில்லை.

## Social links / phone / email சேர்ப்பது

**appsettings.json** file-ஐ திறந்து Business பகுதியில் உள்ள காலியான values-ஐ நிரப்புங்கள்:

```json
"Phone": "+91XXXXXXXXXX",
"Email": "your-real-email@example.com",
"Instagram": "https://www.instagram.com/your-real-profile/",
"Facebook": "https://www.facebook.com/your-real-page/",
"Youtube": "https://www.youtube.com/@your-real-channel",
"Whatsapp": "https://wa.me/91XXXXXXXXXX"
```

மேலே இருப்பது format example மட்டுமே. உங்கள் actual links பயன்படுத்துங்கள். மாற்றிய பிறகு terminal-ல் Ctrl+C செய்து `dotnet run` மீண்டும் ஓட்டுங்கள். Phone / email footer-ல் வரும்; social buttons official links-ஐ திறக்கும். Link இல்லாதபோது பொய்யான account-க்கு செல்லாது; link இன்னும் வழங்கப்படவில்லை என்று தெரிவிக்கும்.

## Booking form எப்படி வேலை செய்கிறது?

Customer form submit → ASP.NET validation → reference number → enquiry `Data\inquiries.jsonl` file-ல் சேமிக்கப்படுகிறது.

உதாரணமாக server file-ல் name, phone, route, date, group size மற்றும் notes இருக்கும். இந்த file **wwwroot-க்கு வெளியே** உள்ளது; browser-க்கு download செய்ய public API கொடுக்கப்படவில்லை.

இந்த version **enquiry website**. Online payment, confirmed seats, live availability, email / WhatsApp automatic notification, admin dashboard இல்லை. Operator enquiry file-ஐப் பார்த்து customer-ஐ தொடர்பு கொள்ள வேண்டும். Public business launch-க்கு முன் database / dashboard / backup / verified contact details மற்றும் actual booking policies அமைக்கவும்.

## Files எதற்காக?

| File | எதை மாற்றலாம்? |
|---|---|
| Program.cs | ASP.NET APIs, validation, enquiry storage |
| appsettings.json | Contact & social links |
| wwwroot/index.html | Homepage content |
| wwwroot/packages.html | Package listing page |
| wwwroot/data/packages.json | Popup itinerary data |
| wwwroot/fleet.html | Bus page |
| wwwroot/contact.html | Enquiry form |
| wwwroot/css/site.css | Colours, fonts, spacing, responsive layouts, animations |
| wwwroot/js/site.js | Filters, popups, menu, form submit, animations |

Package data மாற்றினால் listing cards (index.html / packages.html) மற்றும் packages.json இரண்டிலும் ஒரே தகவல் இருக்க வேண்டும். புதிய package ID சேர்த்தால் Program.cs-ன் allowed package list-லும்ச் சேர்க்க வேண்டும்.

## சோதனை முடிவு

ASP.NET .NET 10 build சோதிக்கப்பட்டது. Frontend responsive checks மற்றும் actual enquiry endpoint checks இத்துடன் செய்யப்பட்டன. விவரங்கள் VALIDATION.md-ல் உள்ளன.
