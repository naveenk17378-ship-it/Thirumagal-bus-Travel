# Validation

- ASP.NET Core .NET 10 build: passed, 0 warnings and 0 errors.
- Seven pages checked at 360, 390, 430, 768, 1024 and 1440 pixel widths: no horizontal overflow, one primary heading per page, and all supplied photographs loaded.
- Browser JavaScript errors: none during checks.
- Package category filter, itinerary dialog and Escape close: passed.
- Mobile navigation open and page navigation: passed.
- Package-to-enquiry prefill and quick planner date/package handoff: passed.
- Real ASP.NET enquiry form submission: passed; reference returned and enquiry written to server file.
- Invalid enquiry rejected with HTTP 400: passed.
- Per-IP enquiry rate limit rejected further requests with HTTP 429: passed.
- Gallery expansion and FAQ accordion: passed.
- Unconfigured social link fallback: passed.
- Desktop and mobile screenshots visually inspected.

57 assertions/checks completed with Chromium. The .NET build used SDK 10.0.100. User's installed .NET SDK 10.0.401 is compatible with the net10.0 target.

Actual business photographs, amenities, fares and social profile links were not supplied. Stock images and suggested itineraries are labelled accordingly. No payment gateway, admin dashboard, notification service or live seat inventory is implemented.
