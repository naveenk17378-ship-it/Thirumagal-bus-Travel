# Photograph sources

Photographs are included locally for reliable rendering. They are illustrative stock photographs, not photographs of Thirumagal's actual coach or the named Indian destinations. Replace them with original business and destination photographs before claiming they depict your operator or itinerary.

Original Unsplash image URLs:

- stock-bus.jpg: https://images.unsplash.com/photo-1570125909232-eb263c188f7e
- stock-hills.jpg: https://images.unsplash.com/photo-1470770841072-f978cf4d019e
- stock-road.jpg: https://images.unsplash.com/photo-1500530855697-b586d89ba3ee
- stock-family.jpg: https://images.unsplash.com/photo-1511895426328-dc8714191300
- stock-coast.jpg: https://images.unsplash.com/photo-1507525428034-b723cf961d3e
- stock-forest.jpg: https://images.unsplash.com/photo-1441974231531-c6227db76b6e

Unsplash terms: https://unsplash.com/license

Fonts: Plus Jakarta Sans and DM Sans, loaded from Google Fonts with Arial/sans-serif fallbacks. Geometric SVG icons and the road-inspired T brand mark are included in the page source.
