@echo off
cd /d "%~dp0"
where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 10 SDK is required. Install it from https://dotnet.microsoft.com/download/dotnet/10.0
  pause
  exit /b 1
)
echo Thirumagal Bus Travels
echo Open http://localhost:5000 after the server starts.
echo Keep this window open while using the website.
dotnet run --project "%~dp0ThirumagalBusTravels.csproj"
pause
